# Aegis-eHSM PowerShell Launcher for VS Code on Windows
# Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.

Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host "  AEGIS-eHSM: Lightweight Cryptography & Emulated HSM for IoT Systems" -ForegroundColor Cyan
Write-Host "  Copyright (c) 2026 Samarth Mhaske. All Rights Reserved." -ForegroundColor Gray
Write-Host "==========================================================================" -ForegroundColor Cyan

Write-Host "`n[Step 1/2] Executing Unit & NIST SP 800-232 Verification Suite..." -ForegroundColor Yellow
python -m unittest discover -s tests -v

Write-Host "`n[Step 2/2] Running Full CLI Audit & Side-Channel TVLA Benchmark..." -ForegroundColor Yellow
python run_project.py --mode cli

Write-Host "`nTo launch the live interactive web workbench on http://127.0.0.1:8080, run:" -ForegroundColor Green
Write-Host "  python run_project.py --mode dashboard --port 8080`n" -ForegroundColor White

@echo off
title Aegis-eHSM: IoT Embedded Key Protection Workbench (c) 2026 Samarth Mhaske
color 0B
echo ===============================================================================
echo   AEGIS-eHSM: LIGHTWEIGHT CRYPTOGRAPHY FOR IOT AND EMBEDDED SYSTEMS
echo   Emulated Hardware Security Module for Embedded Key Protection
echo   Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
echo ===============================================================================
echo.
echo   [1] Run Complete CLI Cryptographic Audit, PUF Sim ^& TVLA Benchmarks
echo   [2] Launch Interactive Web Hardware Security Workbench (http://localhost:8080)
echo   [3] Run Automated Unit ^& NIST SP 800-232 Test Suite
echo   [4] Compile ^& Run ANSI C99 Embedded Firmware Reference (requires GCC/MinGW)
echo.
set /p choice="Select an option [1-4, default=2]: "
if "%choice%"=="" set choice=2

if "%choice%"=="1" (
    python run_project.py --mode cli
    pause
    goto :eof
)
if "%choice%"=="2" (
    echo Starting Live Web Workbench on http://127.0.0.1:8080 ...
    start http://127.0.0.1:8080
    python run_project.py --mode dashboard --port 8080
    pause
    goto :eof
)
if "%choice%"=="3" (
    python -m unittest discover -s tests -v
    pause
    goto :eof
)
if "%choice%"=="4" (
    gcc -std=c99 -O2 -Wall -Wextra -Ifirmware/include firmware/src/ascon.c firmware/src/present.c firmware/src/puf_bch.c firmware/src/ehsm_core.c firmware/src/cli_main.c -o firmware/aegis_ehsm_cli.exe
    if exist firmware\aegis_ehsm_cli.exe (
        firmware\aegis_ehsm_cli.exe
    ) else (
        echo [Note] GCC/MinGW not found in PATH. Python engine runs without C compiler.
    )
    pause
    goto :eof
)

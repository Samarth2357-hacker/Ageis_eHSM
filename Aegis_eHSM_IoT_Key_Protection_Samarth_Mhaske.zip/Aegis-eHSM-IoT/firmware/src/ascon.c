/*
 * Aegis-eHSM: Bit-Sliced Constant-Time Ascon-128 AEAD & Ascon-Hash256
 * File: firmware/src/ascon.c
 *
 * Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
 * SPDX-License-Identifier: MIT
 *
 * Implements the NIST SP 800-232 (Ascon v1.2) specification using 64-bit
 * register bit-slicing and 2-share Boolean masking for side-channel resistance.
 */

#include "ehsm.h"
#include <string.h>

/* Initialization Vectors (NIST SP 800-232 / Ascon v1.2) */
#define ASCON_128_IV     UINT64_C(0x80400c0600000000)
#define ASCON_HASH_IV    UINT64_C(0x00400c0000000100)

static const uint8_t ASCON_RC[12] = {
    0xf0, 0xe1, 0xd2, 0xc3, 0xb4, 0xa5,
    0x96, 0x87, 0x78, 0x69, 0x5a, 0x4b
};

static inline uint64_t rotr64(uint64_t x, unsigned int n) {
    return (x >> n) | (x << (64U - n));
}

static inline uint64_t load64_be(const uint8_t *src) {
    return ((uint64_t)src[0] << 56) |
           ((uint64_t)src[1] << 48) |
           ((uint64_t)src[2] << 40) |
           ((uint64_t)src[3] << 32) |
           ((uint64_t)src[4] << 24) |
           ((uint64_t)src[5] << 16) |
           ((uint64_t)src[6] <<  8) |
           ((uint64_t)src[7]);
}

static inline void store64_be(uint8_t *dst, uint64_t w) {
    dst[0] = (uint8_t)(w >> 56);
    dst[1] = (uint8_t)(w >> 48);
    dst[2] = (uint8_t)(w >> 40);
    dst[3] = (uint8_t)(w >> 32);
    dst[4] = (uint8_t)(w >> 24);
    dst[5] = (uint8_t)(w >> 16);
    dst[6] = (uint8_t)(w >>  8);
    dst[7] = (uint8_t)(w);
}

/*
 * Constant-Time 320-bit Ascon Permutation
 * Executes rounds [start_round .. 11] with zero table lookups or secret branches.
 */
void ascon_permute(ascon_state_t *s, uint8_t start_round) {
    uint64_t x0 = s->x0;
    uint64_t x1 = s->x1;
    uint64_t x2 = s->x2;
    uint64_t x3 = s->x3;
    uint64_t x4 = s->x4;

    for (uint8_t r = start_round; r < 12U; ++r) {
        /* 1. Addition of Round Constant */
        x2 ^= (uint64_t)ASCON_RC[r];

        /* 2. Substitution Layer (5-bit bit-sliced S-box across 64 columns) */
        x0 ^= x4;
        x4 ^= x3;
        x2 ^= x1;

        uint64_t t0 = (~x0) & x1;
        uint64_t t1 = (~x1) & x2;
        uint64_t t2 = (~x2) & x3;
        uint64_t t3 = (~x3) & x4;
        uint64_t t4 = (~x4) & x0;

        x0 ^= t1;
        x1 ^= t2;
        x2 ^= t3;
        x3 ^= t4;
        x4 ^= t0;

        x1 ^= x0;
        x0 ^= x4;
        x3 ^= x2;
        x2 = ~x2;

        /* 3. Linear Diffusion Layer (Sigma_0 .. Sigma_4) */
        x0 ^= rotr64(x0, 19) ^ rotr64(x0, 28);
        x1 ^= rotr64(x1, 61) ^ rotr64(x1, 39);
        x2 ^= rotr64(x2,  1) ^ rotr64(x2,  6);
        x3 ^= rotr64(x3, 10) ^ rotr64(x3, 17);
        x4 ^= rotr64(x4,  7) ^ rotr64(x4, 41);
    }

    s->x0 = x0;
    s->x1 = x1;
    s->x2 = x2;
    s->x3 = x3;
    s->x4 = x4;
}

/*
 * First-Order Boolean Masked Permutation (2-Share Domain-Oriented Masking)
 * Protects against Differential Power Analysis (DPA) and Correlation Power Analysis (CPA).
 * Invariant: (s_share0 ^ s_share1) == unmasked state at every round boundary.
 */
void ascon_permute_masked(ascon_state_t *a, ascon_state_t *b, uint8_t start_round) {
    for (uint8_t r = start_round; r < 12U; ++r) {
        /* Round constant XORed into Share 0 only */
        a->x2 ^= (uint64_t)ASCON_RC[r];

        /* Affine pre-layer on both shares */
        a->x0 ^= a->x4; b->x0 ^= b->x4;
        a->x4 ^= a->x3; b->x4 ^= b->x3;
        a->x2 ^= a->x1; b->x2 ^= b->x1;

        /* Masked Chi Layer: (~x_i & x_{i+1}) where ~x_i flips Share 0 */
        uint64_t na0 = ~a->x0, nb0 = b->x0;
        uint64_t na1 = ~a->x1, nb1 = b->x1;
        uint64_t na2 = ~a->x2, nb2 = b->x2;
        uint64_t na3 = ~a->x3, nb3 = b->x3;
        uint64_t na4 = ~a->x4, nb4 = b->x4;

        uint64_t t0_a = (na0 & a->x1) ^ (na0 & b->x1);
        uint64_t t0_b = (nb0 & a->x1) ^ (nb0 & b->x1);

        uint64_t t1_a = (na1 & a->x2) ^ (na1 & b->x2);
        uint64_t t1_b = (nb1 & a->x2) ^ (nb1 & b->x2);

        uint64_t t2_a = (na2 & a->x3) ^ (na2 & b->x3);
        uint64_t t2_b = (nb2 & a->x3) ^ (nb2 & b->x3);

        uint64_t t3_a = (na3 & a->x4) ^ (na3 & b->x4);
        uint64_t t3_b = (nb3 & a->x4) ^ (nb3 & b->x4);

        uint64_t t4_a = (na4 & a->x0) ^ (na4 & b->x0);
        uint64_t t4_b = (nb4 & a->x0) ^ (nb4 & b->x0);

        a->x0 ^= t1_a; b->x0 ^= t1_b;
        a->x1 ^= t2_a; b->x1 ^= t2_b;
        a->x2 ^= t3_a; b->x2 ^= t3_b;
        a->x3 ^= t4_a; b->x3 ^= t4_b;
        a->x4 ^= t0_a; b->x4 ^= t0_b;

        /* Affine post-layer */
        a->x1 ^= a->x0; b->x1 ^= b->x0;
        a->x0 ^= a->x4; b->x0 ^= b->x4;
        a->x3 ^= a->x2; b->x3 ^= b->x2;
        a->x2 = ~a->x2; /* Complement Share 0 only */

        /* Linear diffusion is independent per share */
        a->x0 ^= rotr64(a->x0, 19) ^ rotr64(a->x0, 28);
        b->x0 ^= rotr64(b->x0, 19) ^ rotr64(b->x0, 28);

        a->x1 ^= rotr64(a->x1, 61) ^ rotr64(a->x1, 39);
        b->x1 ^= rotr64(b->x1, 61) ^ rotr64(b->x1, 39);

        a->x2 ^= rotr64(a->x2,  1) ^ rotr64(a->x2,  6);
        b->x2 ^= rotr64(b->x2,  1) ^ rotr64(b->x2,  6);

        a->x3 ^= rotr64(a->x3, 10) ^ rotr64(a->x3, 17);
        b->x3 ^= rotr64(b->x3, 10) ^ rotr64(b->x3, 17);

        a->x4 ^= rotr64(a->x4,  7) ^ rotr64(a->x4, 41);
        b->x4 ^= rotr64(b->x4,  7) ^ rotr64(b->x4, 41);
    }
}

static uint64_t pad_partial_block(const uint8_t *data, size_t len) {
    uint64_t w = UINT64_C(0x80) << (56U - 8U * (unsigned int)len);
    for (size_t i = 0; i < len; ++i) {
        w |= (uint64_t)data[i] << (56U - 8U * (unsigned int)i);
    }
    return w;
}

void ascon128_aead_encrypt(
    uint8_t *ciphertext,
    uint8_t tag[EHSM_TAG_SIZE_BYTES],
    const uint8_t *plaintext, size_t pt_len,
    const uint8_t *assoc_data, size_t ad_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t key[EHSM_KEY_SIZE_BYTES]
) {
    const uint64_t k0 = load64_be(key);
    const uint64_t k1 = load64_be(key + 8);
    const uint64_t n0 = load64_be(nonce);
    const uint64_t n1 = load64_be(nonce + 8);

    ascon_state_t s = { ASCON_128_IV, k0, k1, n0, n1 };
    ascon_permute(&s, 0U); /* 12-round initialization */
    s.x3 ^= k0;
    s.x4 ^= k1;

    /* Absorb Associated Data (rate = 64 bits, b = 6 rounds) */
    if (ad_len > 0U) {
        while (ad_len >= 8U) {
            s.x0 ^= load64_be(assoc_data);
            ascon_permute(&s, 6U);
            assoc_data += 8U;
            ad_len -= 8U;
        }
        s.x0 ^= pad_partial_block(assoc_data, ad_len);
        ascon_permute(&s, 6U);
    }
    /* Domain separation bit */
    s.x4 ^= UINT64_C(1);

    /* Encrypt Plaintext */
    while (pt_len >= 8U) {
        s.x0 ^= load64_be(plaintext);
        store64_be(ciphertext, s.x0);
        ascon_permute(&s, 6U);
        plaintext += 8U;
        ciphertext += 8U;
        pt_len -= 8U;
    }
    s.x0 ^= pad_partial_block(plaintext, pt_len);
    for (size_t i = 0; i < pt_len; ++i) {
        ciphertext[i] = (uint8_t)(s.x0 >> (56U - 8U * (unsigned int)i));
    }

    /* Finalization & Tag Generation (a = 12 rounds) */
    s.x1 ^= k0;
    s.x2 ^= k1;
    ascon_permute(&s, 0U);
    s.x3 ^= k0;
    s.x4 ^= k1;

    store64_be(tag, s.x3);
    store64_be(tag + 8, s.x4);
}

ehsm_status_t ascon128_aead_decrypt(
    uint8_t *plaintext,
    const uint8_t *ciphertext, size_t ct_len,
    const uint8_t tag[EHSM_TAG_SIZE_BYTES],
    const uint8_t *assoc_data, size_t ad_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t key[EHSM_KEY_SIZE_BYTES]
) {
    const uint64_t k0 = load64_be(key);
    const uint64_t k1 = load64_be(key + 8);
    const uint64_t n0 = load64_be(nonce);
    const uint64_t n1 = load64_be(nonce + 8);

    ascon_state_t s = { ASCON_128_IV, k0, k1, n0, n1 };
    ascon_permute(&s, 0U);
    s.x3 ^= k0;
    s.x4 ^= k1;

    if (ad_len > 0U) {
        while (ad_len >= 8U) {
            s.x0 ^= load64_be(assoc_data);
            ascon_permute(&s, 6U);
            assoc_data += 8U;
            ad_len -= 8U;
        }
        s.x0 ^= pad_partial_block(assoc_data, ad_len);
        ascon_permute(&s, 6U);
    }
    s.x4 ^= UINT64_C(1);

    size_t orig_len = ct_len;
    uint8_t *pt_cursor = plaintext;

    while (ct_len >= 8U) {
        uint64_t c0 = load64_be(ciphertext);
        store64_be(pt_cursor, s.x0 ^ c0);
        s.x0 = c0;
        ascon_permute(&s, 6U);
        ciphertext += 8U;
        pt_cursor += 8U;
        ct_len -= 8U;
    }

    /* Final partial ciphertext block */
    uint64_t c_last = 0;
    for (size_t i = 0; i < ct_len; ++i) {
        c_last |= (uint64_t)ciphertext[i] << (56U - 8U * (unsigned int)i);
    }
    uint64_t mask = (ct_len == 0U) ? UINT64_C(0) : (~UINT64_C(0) << (64U - 8U * (unsigned int)ct_len));
    uint64_t p_last = (s.x0 ^ c_last) & mask;
    for (size_t i = 0; i < ct_len; ++i) {
        pt_cursor[i] = (uint8_t)(p_last >> (56U - 8U * (unsigned int)i));
    }
    s.x0 = (s.x0 & ~mask) | c_last;
    s.x0 ^= UINT64_C(0x80) << (56U - 8U * (unsigned int)ct_len);

    /* Finalization */
    s.x1 ^= k0;
    s.x2 ^= k1;
    ascon_permute(&s, 0U);
    s.x3 ^= k0;
    s.x4 ^= k1;

    uint8_t calc_tag[EHSM_TAG_SIZE_BYTES];
    store64_be(calc_tag, s.x3);
    store64_be(calc_tag + 8, s.x4);

    /* Constant-Time Tag Verification (Zero Early-Exit Timing Side-Channel) */
    uint8_t diff = 0U;
    for (size_t i = 0; i < EHSM_TAG_SIZE_BYTES; ++i) {
        diff |= (calc_tag[i] ^ tag[i]);
    }

    if (diff != 0U) {
        /* Scrub unauthenticated plaintext immediately */
        memset(plaintext, 0, orig_len);
        return EHSM_ERR_AUTH_TAG_MISMATCH;
    }
    return EHSM_OK;
}

void ascon_hash256(uint8_t out[EHSM_HASH_SIZE_BYTES], const uint8_t *in, size_t in_len) {
    ascon_state_t s = { ASCON_HASH_IV, 0, 0, 0, 0 };
    ascon_permute(&s, 0U);

    while (in_len >= 8U) {
        s.x0 ^= load64_be(in);
        ascon_permute(&s, 0U);
        in += 8U;
        in_len -= 8U;
    }
    s.x0 ^= pad_partial_block(in, in_len);
    ascon_permute(&s, 0U);

    for (size_t i = 0; i < 4U; ++i) {
        store64_be(out + (i * 8U), s.x0);
        if (i < 3U) {
            ascon_permute(&s, 0U);
        }
    }
}

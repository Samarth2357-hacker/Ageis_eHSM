/*
 * Aegis-eHSM: Core Security Module, Key Hierarchy & Fault Injection Defense
 * File: firmware/src/ehsm_core.c
 *
 * Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
 * SPDX-License-Identifier: MIT
 */

#include "ehsm.h"
#include <string.h>

static void volatile_zeroize(void *ptr, size_t len) {
    volatile uint8_t *p = (volatile uint8_t *)ptr;
    while (len--) {
        *p++ = 0U;
    }
}

void ehsm_zeroize_all(ehsm_ctx_t *ctx) {
    if (ctx != NULL) {
        uint32_t alerts = ctx->fault_alerts;
        volatile_zeroize(ctx, sizeof(ehsm_ctx_t));
        ctx->fault_alerts = alerts + 1U;
        ctx->tamper_latched = 1U;
    }
}

/* Verify Dual-Modular Redundancy (DMR) invariant: key[i] ^ key_inv[i] == 0xFF */
static ehsm_status_t verify_slot_integrity(ehsm_ctx_t *ctx, const ehsm_key_slot_t *slot) {
    uint8_t fault_acc = 0U;
    for (size_t i = 0; i < EHSM_KEY_SIZE_BYTES; ++i) {
        fault_acc |= (uint8_t)((slot->key[i] ^ slot->key_inv[i]) ^ 0xFFU);
    }
    if (fault_acc != 0U) {
        ehsm_zeroize_all(ctx);
        return EHSM_ERR_FAULT_INJECTION;
    }
    return EHSM_OK;
}

ehsm_status_t ehsm_boot_from_puf(
    ehsm_ctx_t *ctx,
    const ehsm_puf_helper_t *helper,
    const uint16_t noisy_sram[EHSM_PUF_CELLS],
    uint32_t *corrected_bits
) {
    if (ctx == NULL || helper == NULL || noisy_sram == NULL) {
        return EHSM_ERR_INVALID_ARG;
    }
    volatile_zeroize(ctx, sizeof(ehsm_ctx_t));

    uint8_t raw_root[EHSM_ROOT_KEY_BYTES];
    ehsm_status_t st = ehsm_puf_reconstruct(helper, noisy_sram, raw_root, corrected_bits);
    if (st != EHSM_OK) {
        return st;
    }

    /* Split 256-bit Root Key into Boolean Masked Shares in SRAM */
    ctx->prng_state = 0x6C078965U;
    for (size_t i = 0; i < EHSM_ROOT_KEY_BYTES; ++i) {
        ctx->prng_state = ctx->prng_state * 1664525U + 1013904223U;
        uint8_t mask = (uint8_t)(ctx->prng_state >> 24U);
        ctx->root_secret_mask[i] = mask;
        ctx->root_secret[i] = raw_root[i] ^ mask;
    }
    volatile_zeroize(raw_root, sizeof(raw_root));

    ctx->boot_epoch = 1U;
    ctx->initialized = 1U;
    ctx->tamper_latched = 0U;
    return EHSM_OK;
}

ehsm_status_t ehsm_derive_slot_key(
    ehsm_ctx_t *ctx,
    uint8_t slot_id,
    const uint8_t *context_label,
    size_t label_len,
    uint32_t permissions
) {
    if (ctx == NULL || !ctx->initialized || ctx->tamper_latched) {
        return EHSM_ERR_NOT_INITIALIZED;
    }
    if (slot_id >= EHSM_MAX_KEY_SLOTS || context_label == NULL) {
        return EHSM_ERR_SLOT_INVALID;
    }
    if (ctx->slots[slot_id].locked) {
        return EHSM_ERR_SLOT_LOCKED;
    }

    /* Recombine Root Key transiently inside stack buffer for KDF */
    uint8_t kdf_input[EHSM_ROOT_KEY_BYTES + 64U];
    for (size_t i = 0; i < EHSM_ROOT_KEY_BYTES; ++i) {
        kdf_input[i] = ctx->root_secret[i] ^ ctx->root_secret_mask[i];
    }
    size_t copy_len = (label_len > 60U) ? 60U : label_len;
    memcpy(kdf_input + EHSM_ROOT_KEY_BYTES, context_label, copy_len);
    kdf_input[EHSM_ROOT_KEY_BYTES + copy_len]     = slot_id;
    kdf_input[EHSM_ROOT_KEY_BYTES + copy_len + 1] = (uint8_t)(permissions & 0xFFU);

    uint8_t digest[EHSM_HASH_SIZE_BYTES];
    ascon_hash256(digest, kdf_input, EHSM_ROOT_KEY_BYTES + copy_len + 2U);
    volatile_zeroize(kdf_input, sizeof(kdf_input));

    ehsm_key_slot_t *slot = &ctx->slots[slot_id];
    for (size_t i = 0; i < EHSM_KEY_SIZE_BYTES; ++i) {
        slot->key[i]     = digest[i];
        slot->key_inv[i] = (uint8_t)(~digest[i]);
    }
    volatile_zeroize(digest, sizeof(digest));

    slot->slot_id = slot_id;
    slot->permissions = permissions & (~EHSM_PERM_EXPORTABLE);
    slot->monotonic_counter = 0U;
    slot->active = 1U;
    ctx->total_ops++;
    return EHSM_OK;
}

ehsm_status_t ehsm_import_wrapped_key(
    ehsm_ctx_t *ctx,
    uint8_t wrapping_slot,
    uint8_t target_slot,
    const uint8_t *wrapped_blob,
    size_t blob_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t tag[EHSM_TAG_SIZE_BYTES],
    uint32_t permissions
) {
    if (ctx == NULL || !ctx->initialized || ctx->tamper_latched) {
        return EHSM_ERR_NOT_INITIALIZED;
    }
    if (wrapping_slot >= EHSM_MAX_KEY_SLOTS || target_slot >= EHSM_MAX_KEY_SLOTS) {
        return EHSM_ERR_SLOT_INVALID;
    }
    if (blob_len != EHSM_KEY_SIZE_BYTES) {
        return EHSM_ERR_INVALID_ARG;
    }

    ehsm_key_slot_t *kek = &ctx->slots[wrapping_slot];
    if (!kek->active || !(kek->permissions & EHSM_PERM_DECRYPT)) {
        return EHSM_ERR_PERMISSION_DENIED;
    }
    ehsm_status_t st = verify_slot_integrity(ctx, kek);
    if (st != EHSM_OK) return st;

    uint8_t unwrapped[EHSM_KEY_SIZE_BYTES];
    uint8_t ad[2] = { wrapping_slot, target_slot };
    st = ascon128_aead_decrypt(unwrapped, wrapped_blob, blob_len, tag, ad, sizeof(ad), nonce, kek->key);
    if (st != EHSM_OK) {
        return st;
    }

    ehsm_key_slot_t *dst = &ctx->slots[target_slot];
    for (size_t i = 0; i < EHSM_KEY_SIZE_BYTES; ++i) {
        dst->key[i]     = unwrapped[i];
        dst->key_inv[i] = (uint8_t)(~unwrapped[i]);
    }
    volatile_zeroize(unwrapped, sizeof(unwrapped));

    dst->slot_id = target_slot;
    dst->permissions = permissions;
    dst->monotonic_counter = 0U;
    dst->active = 1U;
    ctx->total_ops++;
    return EHSM_OK;
}

ehsm_status_t ehsm_seal_telemetry(
    ehsm_ctx_t *ctx,
    uint8_t slot_id,
    const uint8_t *sensor_header, size_t hdr_len,
    const uint8_t *payload, size_t payload_len,
    uint8_t *out_ciphertext,
    uint8_t out_nonce[EHSM_NONCE_SIZE_BYTES],
    uint8_t out_tag[EHSM_TAG_SIZE_BYTES]
) {
    if (ctx == NULL || !ctx->initialized || ctx->tamper_latched) {
        return EHSM_ERR_NOT_INITIALIZED;
    }
    if (slot_id >= EHSM_MAX_KEY_SLOTS) {
        return EHSM_ERR_SLOT_INVALID;
    }

    ehsm_key_slot_t *slot = &ctx->slots[slot_id];
    if (!slot->active || !(slot->permissions & EHSM_PERM_ENCRYPT)) {
        return EHSM_ERR_PERMISSION_DENIED;
    }

    ehsm_status_t st = verify_slot_integrity(ctx, slot);
    if (st != EHSM_OK) return st;

    slot->monotonic_counter++;
    uint64_t ctr = slot->monotonic_counter;

    /* Construct deterministic replay-safe 128-bit Nonce: [BootEpoch:64 | SlotCounter:64] */
    for (int i = 0; i < 8; ++i) {
        out_nonce[i]     = (uint8_t)((ctx->boot_epoch >> (56 - i * 8)) & 0xFFU);
        out_nonce[8 + i] = (uint8_t)((ctr >> (56 - i * 8)) & 0xFFU);
    }

    /* Execute Dual-Modular Redundant Encryption to detect Fault/Glitch Injection */
    uint8_t tag_shadow[EHSM_TAG_SIZE_BYTES];
    ascon128_aead_encrypt(out_ciphertext, out_tag, payload, payload_len, sensor_header, hdr_len, out_nonce, slot->key);

    /* Reconstruct key from complementary share and verify tag agreement */
    uint8_t key_check[EHSM_KEY_SIZE_BYTES];
    for (size_t i = 0; i < EHSM_KEY_SIZE_BYTES; ++i) {
        key_check[i] = (uint8_t)(~slot->key_inv[i]);
    }
    ascon128_aead_encrypt(out_ciphertext, tag_shadow, payload, payload_len, sensor_header, hdr_len, out_nonce, key_check);
    volatile_zeroize(key_check, sizeof(key_check));

    uint8_t fault_diff = 0U;
    for (size_t i = 0; i < EHSM_TAG_SIZE_BYTES; ++i) {
        fault_diff |= (out_tag[i] ^ tag_shadow[i]);
    }
    if (fault_diff != 0U) {
        ehsm_zeroize_all(ctx);
        return EHSM_ERR_FAULT_INJECTION;
    }

    ctx->total_ops++;
    return EHSM_OK;
}

ehsm_status_t ehsm_unseal_telemetry(
    ehsm_ctx_t *ctx,
    uint8_t slot_id,
    const uint8_t *sensor_header, size_t hdr_len,
    const uint8_t *ciphertext, size_t ct_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t tag[EHSM_TAG_SIZE_BYTES],
    uint8_t *out_plaintext
) {
    if (ctx == NULL || !ctx->initialized || ctx->tamper_latched) {
        return EHSM_ERR_NOT_INITIALIZED;
    }
    if (slot_id >= EHSM_MAX_KEY_SLOTS) {
        return EHSM_ERR_SLOT_INVALID;
    }

    ehsm_key_slot_t *slot = &ctx->slots[slot_id];
    if (!slot->active || !(slot->permissions & EHSM_PERM_DECRYPT)) {
        return EHSM_ERR_PERMISSION_DENIED;
    }

    ehsm_status_t st = verify_slot_integrity(ctx, slot);
    if (st != EHSM_OK) return st;

    st = ascon128_aead_decrypt(out_plaintext, ciphertext, ct_len, tag, sensor_header, hdr_len, nonce, slot->key);
    if (st == EHSM_OK) {
        ctx->total_ops++;
    }
    return st;
}

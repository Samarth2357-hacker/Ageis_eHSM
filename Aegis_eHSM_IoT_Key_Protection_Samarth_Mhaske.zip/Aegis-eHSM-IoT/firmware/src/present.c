/*
 * Aegis-eHSM: ISO/IEC 29192-2 PRESENT-80 Ultra-Lightweight Block Cipher
 * File: firmware/src/present.c
 *
 * Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
 * SPDX-License-Identifier: MIT
 *
 * 31-round Substitution-Permutation Network (SPN) operating on 64-bit blocks
 * with an 80-bit key for ultra-constrained RFID and sub-milliwatt IoT tags.
 */

#include "ehsm.h"

static const uint8_t PRESENT_SBOX[16] = {
    0xC, 0x5, 0x6, 0xB, 0x9, 0x0, 0xA, 0xD,
    0x3, 0xE, 0xF, 0x8, 0x4, 0x7, 0x1, 0x2
};

static const uint8_t PRESENT_INV_SBOX[16] = {
    0x5, 0xE, 0xF, 0x8, 0xC, 0x1, 0x2, 0xD,
    0xB, 0x4, 0x6, 0x3, 0x0, 0x7, 0x9, 0xA
};

static uint64_t apply_sbox_layer(uint64_t state, const uint8_t sbox[16]) {
    uint64_t out = 0;
    for (unsigned int i = 0; i < 16U; ++i) {
        uint8_t nibble = (uint8_t)((state >> (i * 4U)) & 0xFU);
        out |= ((uint64_t)sbox[nibble]) << (i * 4U);
    }
    return out;
}

static uint64_t p_layer(uint64_t state) {
    uint64_t out = 0;
    for (unsigned int i = 0; i < 64U; ++i) {
        unsigned int pos = (i == 63U) ? 63U : ((16U * i) % 63U);
        out |= ((state >> i) & UINT64_C(1)) << pos;
    }
    return out;
}

static uint64_t inv_p_layer(uint64_t state) {
    uint64_t out = 0;
    for (unsigned int i = 0; i < 64U; ++i) {
        unsigned int src = (i == 63U) ? 63U : ((16U * i) % 63U);
        out |= ((state >> src) & UINT64_C(1)) << i;
    }
    return out;
}

static void generate_round_keys(const uint8_t key[PRESENT_KEY_80_BYTES], uint64_t rkeys[32]) {
    uint64_t k_high = 0;
    for (int i = 0; i < 8; ++i) {
        k_high = (k_high << 8) | key[i];
    }
    uint16_t k_low = ((uint16_t)key[8] << 8) | key[9];

    for (unsigned int round = 1U; round <= 32U; ++round) {
        rkeys[round - 1U] = k_high;

        /* 61-bit left rotation of 80-bit key register (k_high: 64b, k_low: 16b) */
        uint64_t next_high = (k_high << 61) | ((uint64_t)k_low << 45) | (k_high >> 19);
        uint16_t next_low  = (uint16_t)((k_high >> 3) & 0xFFFFU);

        /* Apply S-box to top 4 bits [79..76] */
        uint8_t top_nibble = (uint8_t)((next_high >> 60) & 0xFU);
        next_high = (next_high & UINT64_C(0x0FFFFFFFFFFFFFFF)) |
                    ((uint64_t)PRESENT_SBOX[top_nibble] << 60);

        /* XOR 5-bit round counter into bits [19..15] */
        next_high ^= ((uint64_t)(round >> 1)) << 0;
        next_low  ^= (uint16_t)((round & 1U) << 15);

        k_high = next_high;
        k_low  = next_low;
    }
}

void present80_encrypt_block(uint8_t block[PRESENT_BLOCK_SIZE_BYTES], const uint8_t key[PRESENT_KEY_80_BYTES]) {
    uint64_t rkeys[32];
    generate_round_keys(key, rkeys);

    uint64_t state = 0;
    for (int i = 0; i < 8; ++i) {
        state = (state << 8) | block[i];
    }

    for (int r = 0; r < 31; ++r) {
        state ^= rkeys[r];
        state = apply_sbox_layer(state, PRESENT_SBOX);
        state = p_layer(state);
    }
    state ^= rkeys[31];

    for (int i = 7; i >= 0; --i) {
        block[i] = (uint8_t)(state & 0xFFU);
        state >>= 8;
    }
}

void present80_decrypt_block(uint8_t block[PRESENT_BLOCK_SIZE_BYTES], const uint8_t key[PRESENT_KEY_80_BYTES]) {
    uint64_t rkeys[32];
    generate_round_keys(key, rkeys);

    uint64_t state = 0;
    for (int i = 0; i < 8; ++i) {
        state = (state << 8) | block[i];
    }

    state ^= rkeys[31];
    for (int r = 30; r >= 0; --r) {
        state = inv_p_layer(state);
        state = apply_sbox_layer(state, PRESENT_INV_SBOX);
        state ^= rkeys[r];
    }

    for (int i = 7; i >= 0; --i) {
        block[i] = (uint8_t)(state & 0xFFU);
        state >>= 8;
    }
}

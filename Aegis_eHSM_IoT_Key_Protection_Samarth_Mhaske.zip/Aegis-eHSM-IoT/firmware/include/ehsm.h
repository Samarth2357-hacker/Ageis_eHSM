/*
 * Aegis-eHSM: Lightweight Cryptographic Emulated Hardware Security Module
 * File: firmware/include/ehsm.h
 *
 * Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
 * SPDX-License-Identifier: MIT
 *
 * Designed for resource-constrained 32-bit/64-bit microcontrollers
 * (ARM Cortex-M0+/M4, RISC-V RV32IMC, ESP32) with zero dynamic heap allocation.
 */

#ifndef AEGIS_EHSM_H
#define AEGIS_EHSM_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Architectural Constants */
#define EHSM_MAX_KEY_SLOTS         8U
#define EHSM_KEY_SIZE_BYTES        16U   /* 128-bit operational keys */
#define EHSM_ROOT_KEY_BYTES        32U   /* 256-bit PUF Root of Trust */
#define EHSM_NONCE_SIZE_BYTES      16U   /* 128-bit Ascon nonce */
#define EHSM_TAG_SIZE_BYTES        16U   /* 128-bit authentication tag */
#define EHSM_HASH_SIZE_BYTES       32U   /* 256-bit Ascon-Hash output */
#define EHSM_PUF_CELLS             256U  /* 256 words x 15-bit BCH codewords */
#define PRESENT_BLOCK_SIZE_BYTES   8U    /* 64-bit ultra-lightweight block */
#define PRESENT_KEY_80_BYTES       10U   /* 80-bit PRESENT key */

/* Status & Fault Return Codes */
typedef enum {
    EHSM_OK                        =  0,
    EHSM_ERR_INVALID_ARG           = -1,
    EHSM_ERR_SLOT_INVALID          = -2,
    EHSM_ERR_SLOT_LOCKED           = -3,
    EHSM_ERR_PERMISSION_DENIED     = -4,
    EHSM_ERR_AUTH_TAG_MISMATCH     = -5,
    EHSM_ERR_REPLAY_DETECTED       = -6,
    EHSM_ERR_PUF_RECONSTRUCT_FAIL  = -7,
    EHSM_ERR_FAULT_INJECTION       = -8,
    EHSM_ERR_NOT_INITIALIZED       = -9
} ehsm_status_t;

/* Key Slot Permission Flags (Bitmask) */
#define EHSM_PERM_ENCRYPT          (1U << 0)
#define EHSM_PERM_DECRYPT          (1U << 1)
#define EHSM_PERM_MAC_GEN          (1U << 2)
#define EHSM_PERM_DERIVE           (1U << 3)
#define EHSM_PERM_EXPORTABLE       (1U << 4) /* Never set on Hardware-Bound Keys */

/* 320-bit Ascon Sponge State (5 x 64-bit registers) */
typedef struct {
    uint64_t x0;
    uint64_t x1;
    uint64_t x2;
    uint64_t x3;
    uint64_t x4;
} ascon_state_t;

/* Key Slot Metadata & Isolated Storage (Lives solely in protected SRAM) */
typedef struct {
    uint8_t  key[EHSM_KEY_SIZE_BYTES];
    uint8_t  key_inv[EHSM_KEY_SIZE_BYTES]; /* Complementary share for DMR fault check */
    uint32_t slot_id;
    uint32_t permissions;
    uint64_t monotonic_counter;
    uint8_t  active;
    uint8_t  locked;
} ehsm_key_slot_t;

/* PUF Enrollment Helper Data Record (Safe to store in public Flash/NVM) */
typedef struct {
    uint16_t helper_codewords[EHSM_PUF_CELLS]; /* 15-bit BCH(15,7,5) syndrome helpers */
    uint8_t  enrollment_digest[EHSM_HASH_SIZE_BYTES];
    uint8_t  enrolled;
} ehsm_puf_helper_t;

/* Complete Emulated HSM Context (Zero Heap Footprint) */
typedef struct {
    uint8_t           root_secret[EHSM_ROOT_KEY_BYTES];
    uint8_t           root_secret_mask[EHSM_ROOT_KEY_BYTES]; /* Boolean mask share */
    ehsm_key_slot_t   slots[EHSM_MAX_KEY_SLOTS];
    uint64_t          boot_epoch;
    uint64_t          total_ops;
    uint32_t          fault_alerts;
    uint32_t          prng_state;
    uint8_t           initialized;
    uint8_t           tamper_latched;
} ehsm_ctx_t;

/* --- Low-Level NIST SP 800-232 Ascon-128 & Ascon-Hash256 Primitives --- */
void ascon_permute(ascon_state_t *s, uint8_t start_round);
void ascon_permute_masked(ascon_state_t *s_share0, ascon_state_t *s_share1, uint8_t start_round);

void ascon128_aead_encrypt(
    uint8_t *ciphertext,
    uint8_t tag[EHSM_TAG_SIZE_BYTES],
    const uint8_t *plaintext, size_t pt_len,
    const uint8_t *assoc_data, size_t ad_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t key[EHSM_KEY_SIZE_BYTES]
);

ehsm_status_t ascon128_aead_decrypt(
    uint8_t *plaintext,
    const uint8_t *ciphertext, size_t ct_len,
    const uint8_t tag[EHSM_TAG_SIZE_BYTES],
    const uint8_t *assoc_data, size_t ad_len,
    const uint8_t nonce[EHSM_NONCE_SIZE_BYTES],
    const uint8_t key[EHSM_KEY_SIZE_BYTES]
);

void ascon_hash256(uint8_t out[EHSM_HASH_SIZE_BYTES], const uint8_t *in, size_t in_len);

/* --- ISO/IEC 29192-2 PRESENT-80 Ultra-Lightweight Block Cipher --- */
void present80_encrypt_block(uint8_t block[PRESENT_BLOCK_SIZE_BYTES], const uint8_t key[PRESENT_KEY_80_BYTES]);
void present80_decrypt_block(uint8_t block[PRESENT_BLOCK_SIZE_BYTES], const uint8_t key[PRESENT_KEY_80_BYTES]);

/* --- SRAM PUF & BCH(15,7,5) Fuzzy Extractor --- */
uint16_t bch15_7_encode(uint8_t data7);
uint8_t  bch15_7_decode(uint16_t noisy_codeword, uint8_t *corrected_errors);

void ehsm_puf_simulate_sram(uint16_t raw_cells[EHSM_PUF_CELLS], uint32_t silicon_wafer_id, uint32_t noise_ppm, uint32_t temp_seed);
ehsm_status_t ehsm_puf_enroll(ehsm_puf_helper_t *helper, const uint16_t raw_sram[EHSM_PUF_CELLS], uint8_t derived_root[EHSM_ROOT_KEY_BYTES]);
ehsm_status_t ehsm_puf_reconstruct(const ehsm_puf_helper_t *helper, const uint16_t noisy_sram[EHSM_PUF_CELLS], uint8_t recovered_root[EHSM_ROOT_KEY_BYTES], uint32_t *total_corrected_bits);

/* --- High-Level eHSM API (Key Protection & Fault-Hardened Operations) --- */
ehsm_status_t ehsm_boot_from_puf(ehsm_ctx_t *ctx, const ehsm_puf_helper_t *helper, const uint16_t noisy_sram[EHSM_PUF_CELLS], uint32_t *corrected_bits);
ehsm_status_t ehsm_derive_slot_key(ehsm_ctx_t *ctx, uint8_t slot_id, const uint8_t *context_label, size_t label_len, uint32_t permissions);
ehsm_status_t ehsm_import_wrapped_key(ehsm_ctx_t *ctx, uint8_t wrapping_slot, uint8_t target_slot, const uint8_t *wrapped_blob, size_t blob_len, const uint8_t nonce[EHSM_NONCE_SIZE_BYTES], const uint8_t tag[EHSM_TAG_SIZE_BYTES], uint32_t permissions);
ehsm_status_t ehsm_seal_telemetry(ehsm_ctx_t *ctx, uint8_t slot_id, const uint8_t *sensor_Header, size_t hdr_len, const uint8_t *payload, size_t payload_len, uint8_t *out_ciphertext, uint8_t out_nonce[EHSM_NONCE_SIZE_BYTES], uint8_t out_tag[EHSM_TAG_SIZE_BYTES]);
ehsm_status_t ehsm_unseal_telemetry(ehsm_ctx_t *ctx, uint8_t slot_id, const uint8_t *sensor_header, size_t hdr_len, const uint8_t *ciphertext, size_t ct_len, const uint8_t nonce[EHSM_NONCE_SIZE_BYTES], const uint8_t tag[EHSM_TAG_SIZE_BYTES], uint8_t *out_plaintext);
void          ehsm_zeroize_all(ehsm_ctx_t *ctx);

#ifdef __cplusplus
}
#endif

#endif /* AEGIS_EHSM_H */

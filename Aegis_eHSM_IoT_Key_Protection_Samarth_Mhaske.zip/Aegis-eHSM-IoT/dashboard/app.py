"""
Aegis-eHSM Interactive Web Hardware Security Workbench
Zero-external-dependency HTTP/JSON API Server + Real-Time Cyber Telemetry UI.

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
"""

from __future__ import annotations
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse

from aegis_ehsm import (
    EmulatedHSM,
    KeySlotPermissions,
    HSMSecurityError,
    run_welch_t_test_tvla,
    run_comparative_benchmarks,
)

STATIC_DIR = Path(__file__).resolve().parent / "static"

# Global singleton eHSM instance for live interactive demonstration
GLOBAL_HSM = EmulatedHSM(wafer_die_id=0xC0FFEE42)
GLOBAL_HSM.factory_enroll_puf()
GLOBAL_HSM.derive_key_slot(0, "SMART_GRID_PMU_TELEMETRY", KeySlotPermissions.TELEMETRY_ALL)
GLOBAL_HSM.derive_key_slot(1, "MED_IMPLANT_PACEMAKER_BLE", KeySlotPermissions.TELEMETRY_ALL)
GLOBAL_HSM.derive_key_slot(2, "OTA_FIRMWARE_KEK_MASTER", KeySlotPermissions.TELEMETRY_ALL | KeySlotPermissions.WRAP_UNWRAP)


class WorkbenchRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:
        # Clean console logging
        pass

    def _send_json(self, payload: dict, status: int = 200) -> None:
        raw = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path in ("/", "/index.html"):
            html_bytes = (STATIC_DIR / "index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html_bytes)))
            self.end_headers()
            self.wfile.write(html_bytes)
            return

        if parsed.path == "/api/status":
            self._send_json(GLOBAL_HSM.get_status_snapshot())
            return

        if parsed.path == "/api/benchmarks":
            self._send_json(
                {
                    "benchmarks": run_comparative_benchmarks(),
                    "tvla": run_welch_t_test_tvla(num_traces=600),
                }
            )
            return

        self._send_json({"error": "Endpoint not found"}, status=404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}

        try:
            if parsed.path == "/api/puf_boot":
                temp = float(body.get("temperature_c", 65.0))
                volt = float(body.get("supply_voltage_v", 3.15))
                stats = GLOBAL_HSM.secure_boot_reconstruct(temperature_c=temp, supply_voltage_v=volt)
                GLOBAL_HSM.derive_key_slot(0, "SMART_GRID_PMU_TELEMETRY", KeySlotPermissions.TELEMETRY_ALL)
                GLOBAL_HSM.derive_key_slot(1, "MED_IMPLANT_PACEMAKER_BLE", KeySlotPermissions.TELEMETRY_ALL)
                GLOBAL_HSM.derive_key_slot(2, "OTA_FIRMWARE_KEK_MASTER", KeySlotPermissions.TELEMETRY_ALL | KeySlotPermissions.WRAP_UNWRAP)
                self._send_json({"ok": True, "puf_stats": stats, "status": GLOBAL_HSM.get_status_snapshot()})
                return

            if parsed.path == "/api/derive_slot":
                slot_id = int(body.get("slot_id", 3))
                label = str(body.get("label", f"IOT_SENSOR_SLOT_{slot_id}"))
                res = GLOBAL_HSM.derive_key_slot(slot_id, label, KeySlotPermissions.TELEMETRY_ALL)
                self._send_json({"ok": True, "slot": res, "status": GLOBAL_HSM.get_status_snapshot()})
                return

            if parsed.path == "/api/seal":
                slot_id = int(body.get("slot_id", 0))
                header = str(body.get("header", "NODE:PMU_07|ZONE:PUNE_GRID"))
                payload = str(body.get("payload", "V=230.2V|I=15.8A|FREQ=50.01Hz|STATE=LOCKED"))
                sealed = GLOBAL_HSM.seal_iot_telemetry(slot_id, header, payload)
                self._send_json({"ok": True, "packet": sealed, "status": GLOBAL_HSM.get_status_snapshot()})
                return

            if parsed.path == "/api/unseal":
                slot_id = int(body.get("slot_id", 0))
                header = str(body.get("header", ""))
                ct_hex = str(body.get("ciphertext_hex", ""))
                nonce_hex = str(body.get("nonce_hex", ""))
                tag_hex = str(body.get("tag_hex", ""))
                res = GLOBAL_HSM.unseal_iot_telemetry(slot_id, header, ct_hex, nonce_hex, tag_hex)
                self._send_json({"ok": True, "unsealed": res, "status": GLOBAL_HSM.get_status_snapshot()})
                return

            if parsed.path == "/api/inject_glitch":
                slot_id = int(body.get("slot_id", 0))
                GLOBAL_HSM.inject_fault_glitch(slot_id=slot_id, bit_flip_mask=0x09)
                self._send_json(
                    {
                        "ok": True,
                        "message": f"Injected single-bit SRAM glitch into Slot #{slot_id}. Next crypto op will trigger DMR Tamper Zeroization!",
                        "status": GLOBAL_HSM.get_status_snapshot(),
                    }
                )
                return

            if parsed.path == "/api/zeroize":
                GLOBAL_HSM.zeroize_on_tamper("Operator Emergency Zeroize Button")
                self._send_json({"ok": True, "status": GLOBAL_HSM.get_status_snapshot()})
                return

        except HSMSecurityError as sec_err:
            self._send_json(
                {
                    "ok": False,
                    "security_alert": type(sec_err).__name__,
                    "error": str(sec_err),
                    "status": GLOBAL_HSM.get_status_snapshot(),
                },
                status=400,
            )
            return
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=400)
            return

        self._send_json({"error": "Unknown API action"}, status=404)


def start_workbench_server(host: str = "127.0.0.1", port: int = 8080) -> None:
    server = HTTPServer((host, port), WorkbenchRequestHandler)
    print("============================================================================")
    print("  AEGIS-eHSM INTERACTIVE HARDWARE SECURITY WORKBENCH")
    print("  Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.")
    print(f"  Live Dashboard URL: http://{host}:{port}")
    print("  Press Ctrl+C in terminal to stop the server.")
    print("============================================================================")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[Aegis-eHSM] Shutting down workbench server cleanly.")
        server.server_close()

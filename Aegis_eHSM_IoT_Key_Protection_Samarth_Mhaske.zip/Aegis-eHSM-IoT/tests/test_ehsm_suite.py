"""
Aegis-eHSM Comprehensive Verification Suite:
- NIST SP 800-232 Ascon-128 & Ascon-Hash256 Known Answer Tests (KATs)
- First-Order Boolean Masking Equivalence Invariant
- ISO/IEC 29192-2 PRESENT-80 Standard Test Vectors
- SRAM PUF + BCH(15,7,5) Fuzzy Extractor Thermal Drift Recovery
- eHSM Anti-Rollback, Tag Forgery Rejection, and DMR Fault Zeroization

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
"""

import unittest
from aegis_ehsm import (
    ascon_permutation,
    ascon_permutation_masked,
    ascon128_encrypt,
    ascon128_decrypt,
    ascon_hash256,
    present80_encrypt_block,
    present80_decrypt_block,
    BCH15_7_Codec,
    EmulatedHSM,
    KeySlotPermissions,
    HSMTamperError,
    HSMReplayError,
    HSMAuthError,
    run_welch_t_test_tvla,
)


class TestAegisEHSM(unittest.TestCase):
    def test_nist_ascon128_known_answer_vector(self) -> None:
        """Verifies official NIST LWC Ascon-128 KAT #1 (Empty PT, Empty AD)."""
        key = bytes(range(16))
        nonce = bytes(range(16))
        ct, tag = ascon128_encrypt(key, nonce, b"", b"")
        self.assertEqual(ct, b"")
        self.assertEqual(tag.hex(), "e355159f292911f794cb1432a0103a8a")

    def test_ascon128_roundtrip_and_tamper_rejection(self) -> None:
        key = bytes(range(16))
        nonce = bytes(range(16, 32))
        ad = b"SMART_METER_HEADER_V2"
        pt = b"Telemetry payload: 230.5V, 12.4A, 50.00Hz"
        ct, tag = ascon128_encrypt(key, nonce, ad, pt)
        recovered = ascon128_decrypt(key, nonce, ad, ct, tag)
        self.assertEqual(recovered, pt)

        # Flip 1 bit in ciphertext and verify constant-time tag rejection
        corrupted_ct = bytearray(ct)
        corrupted_ct[3] ^= 0x01
        with self.assertRaises(ValueError):
            ascon128_decrypt(key, nonce, ad, bytes(corrupted_ct), tag)

    def test_boolean_masked_permutation_invariant(self) -> None:
        """Verifies (share_a ^ share_b) == unmasked_state across all 12 rounds."""
        initial = [
            0x80400C0600000000,
            0x0102030405060708,
            0x1112131415161718,
            0x2122232425262728,
            0x3132333435363738,
        ]
        masks = [
            0xA5A5A5A5A5A5A5A5,
            0x5A5A5A5A5A5A5A5A,
            0xF0F0F0F0F0F0F0F0,
            0x0F0F0F0F0F0F0F0F,
            0x123456789ABCDEF0,
        ]
        s_unmasked = list(initial)
        ascon_permutation(s_unmasked, 0)

        share_a = [w ^ m for w, m in zip(initial, masks)]
        share_b = list(masks)
        ascon_permutation_masked(share_a, share_b, 0)

        recombined = [a ^ b for a, b in zip(share_a, share_b)]
        self.assertEqual(recombined, s_unmasked)

    def test_present80_iso_standard_vector(self) -> None:
        """Verifies ISO/IEC 29192-2 PRESENT-80 test vector (All-zero key & block)."""
        key = b"\x00" * 10
        pt = b"\x00" * 8
        ct = present80_encrypt_block(pt, key)
        self.assertEqual(ct.hex().upper(), "5579C1387B228445")
        self.assertEqual(present80_decrypt_block(ct, key), pt)

    def test_bch_15_7_double_error_correction(self) -> None:
        """Verifies BCH(15,7,5) corrects all 1-bit and 2-bit error patterns."""
        for msg in (0, 42, 85, 127):
            cw = BCH15_7_Codec.encode(msg)
            for b1 in range(15):
                for b2 in range(b1, 15):
                    flips = (1 << b1) | (1 << b2)
                    decoded, errs = BCH15_7_Codec.decode(cw ^ flips)
                    self.assertEqual(decoded, msg)
                    self.assertEqual(errs, 1 if b1 == b2 else 2)

    def test_ehsm_puf_lifecycle_and_anti_replay(self) -> None:
        hsm = EmulatedHSM(wafer_die_id=0xDEADBEEF)
        hsm.factory_enroll_puf()
        boot_stats = hsm.secure_boot_reconstruct(temperature_c=80.0, supply_voltage_v=2.95)
        self.assertTrue(boot_stats["root_key_verified"])
        self.assertEqual(boot_stats["post_fec_ber_percent"], 0.0)

        hsm.derive_key_slot(0, "ECU_CAN_BUS_AUTH", KeySlotPermissions.TELEMETRY_ALL)
        pkt = hsm.seal_iot_telemetry(0, "CAN_ID:0x120", "RPM=3200|TORQUE=180Nm")
        res = hsm.unseal_iot_telemetry(
            0, "CAN_ID:0x120", pkt["ciphertext_hex"], pkt["nonce_hex"], pkt["tag_hex"]
        )
        self.assertEqual(res["plaintext"], "RPM=3200|TORQUE=180Nm")

        # Replaying the exact same packet must raise HSMReplayError
        with self.assertRaises(HSMReplayError):
            hsm.unseal_iot_telemetry(
                0, "CAN_ID:0x120", pkt["ciphertext_hex"], pkt["nonce_hex"], pkt["tag_hex"]
            )

    def test_ehsm_dmr_fault_injection_zeroization(self) -> None:
        hsm = EmulatedHSM(wafer_die_id=0xCAFEBABE)
        hsm.factory_enroll_puf()
        hsm.derive_key_slot(0, "CRITICAL_GRID_KEY", KeySlotPermissions.TELEMETRY_ALL)
        hsm.inject_fault_glitch(slot_id=0, bit_flip_mask=0x04)

        with self.assertRaises(HSMTamperError):
            hsm.seal_iot_telemetry(0, "HDR", "PAYLOAD")

        self.assertTrue(hsm.tamper_latched)
        self.assertEqual(len(hsm.slots), 0)

    def test_side_channel_welch_tvla(self) -> None:
        tvla = run_welch_t_test_tvla(num_traces=500, seed=42)
        self.assertGreater(tvla["unprotected_final_t"], 4.5)
        self.assertLess(tvla["masked_final_t"], 4.5)


if __name__ == "__main__":
    unittest.main()

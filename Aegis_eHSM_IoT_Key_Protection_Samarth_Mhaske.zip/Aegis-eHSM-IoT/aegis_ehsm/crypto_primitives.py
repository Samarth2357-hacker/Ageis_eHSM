"""
Aegis-eHSM Cryptographic Primitives:
1. NIST SP 800-232 (Ascon v1.2) Ascon-128 AEAD & Ascon-Hash256
2. First-Order Boolean Masked Ascon Permutation (2-Share DOM Side-Channel Countermeasure)
3. ISO/IEC 29192-2 PRESENT-80 Ultra-Lightweight Block Cipher

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
"""

from __future__ import annotations
import hmac
import struct
from typing import List, Tuple

MASK64 = 0xFFFFFFFFFFFFFFFF

ASCON_128_IV = 0x80400C0600000000
ASCON_128A_IV = 0x80800C0800000000
ASCON_HASH_IV = 0x00400C0000000100

ASCON_ROUND_CONSTANTS = (
    0xF0, 0xE1, 0xD2, 0xC3, 0xB4, 0xA5,
    0x96, 0x87, 0x78, 0x69, 0x5A, 0x4B,
)

PRESENT_SBOX = (
    0xC, 0x5, 0x6, 0xB, 0x9, 0x0, 0xA, 0xD,
    0x3, 0xE, 0xF, 0x8, 0x4, 0x7, 0x1, 0x2,
)
PRESENT_INV_SBOX = (
    0x5, 0xE, 0xF, 0x8, 0xC, 0x1, 0x2, 0xD,
    0xB, 0x4, 0x6, 0x3, 0x0, 0x7, 0x9, 0xA,
)


def _rotr64(val: int, r: int) -> int:
    val &= MASK64
    return ((val >> r) | ((val << (64 - r)) & MASK64)) & MASK64


def ascon_permutation(state: List[int], start_round: int = 0) -> List[int]:
    """
    Bit-sliced 320-bit Ascon sponge permutation executing rounds [start_round..11].
    Operates strictly on five 64-bit unsigned words with zero lookup tables.
    """
    x0, x1, x2, x3, x4 = (
        state[0] & MASK64,
        state[1] & MASK64,
        state[2] & MASK64,
        state[3] & MASK64,
        state[4] & MASK64,
    )

    for r in range(start_round, 12):
        # 1. Constant addition
        x2 ^= ASCON_ROUND_CONSTANTS[r]

        # 2. 5-bit bit-sliced substitution layer (Chi)
        x0 ^= x4
        x4 ^= x3
        x2 ^= x1

        t0 = (~x0 & MASK64) & x1
        t1 = (~x1 & MASK64) & x2
        t2 = (~x2 & MASK64) & x3
        t3 = (~x3 & MASK64) & x4
        t4 = (~x4 & MASK64) & x0

        x0 ^= t1
        x1 ^= t2
        x2 ^= t3
        x3 ^= t4
        x4 ^= t0

        x1 ^= x0
        x0 ^= x4
        x3 ^= x2
        x2 = (~x2) & MASK64

        # 3. Linear diffusion layer
        x0 ^= _rotr64(x0, 19) ^ _rotr64(x0, 28)
        x1 ^= _rotr64(x1, 61) ^ _rotr64(x1, 39)
        x2 ^= _rotr64(x2, 1) ^ _rotr64(x2, 6)
        x3 ^= _rotr64(x3, 10) ^ _rotr64(x3, 17)
        x4 ^= _rotr64(x4, 7) ^ _rotr64(x4, 41)

    state[0], state[1], state[2], state[3], state[4] = x0, x1, x2, x3, x4
    return state


def ascon_permutation_masked(
    share_a: List[int], share_b: List[int], start_round: int = 0
) -> Tuple[List[int], List[int]]:
    """
    First-Order Boolean Masked 320-bit Ascon Permutation.
    Maintains the invariant (share_a[i] ^ share_b[i]) == unmasked_state[i]
    while decorrelating intermediate Hamming-weight power leakage.
    """
    for r in range(start_round, 12):
        share_a[2] = (share_a[2] ^ ASCON_ROUND_CONSTANTS[r]) & MASK64

        share_a[0] ^= share_a[4]
        share_b[0] ^= share_b[4]
        share_a[4] ^= share_a[3]
        share_b[4] ^= share_b[3]
        share_a[2] ^= share_a[1]
        share_b[2] ^= share_b[1]

        na = [(~w) & MASK64 for w in share_a]
        nb = [w & MASK64 for w in share_b]

        ta = [0] * 5
        tb = [0] * 5
        for i in range(5):
            nxt = (i + 1) % 5
            ta[i] = ((na[i] & share_a[nxt]) ^ (na[i] & share_b[nxt])) & MASK64
            tb[i] = ((nb[i] & share_a[nxt]) ^ (nb[i] & share_b[nxt])) & MASK64

        for i in range(5):
            nxt = (i + 1) % 5
            share_a[i] = (share_a[i] ^ ta[nxt]) & MASK64
            share_b[i] = (share_b[i] ^ tb[nxt]) & MASK64

        share_a[1] ^= share_a[0]
        share_b[1] ^= share_b[0]
        share_a[0] ^= share_a[4]
        share_b[0] ^= share_b[4]
        share_a[3] ^= share_a[2]
        share_b[3] ^= share_b[2]
        share_a[2] = (~share_a[2]) & MASK64

        rot_table = ((19, 28), (61, 39), (1, 6), (10, 17), (7, 41))
        for i, (r1, r2) in enumerate(rot_table):
            share_a[i] ^= _rotr64(share_a[i], r1) ^ _rotr64(share_a[i], r2)
            share_b[i] ^= _rotr64(share_b[i], r1) ^ _rotr64(share_b[i], r2)

    return share_a, share_b


def _pad_bytes_to_u64(data: bytes) -> int:
    assert len(data) < 8
    padded = data + b"\x80" + b"\x00" * (7 - len(data))
    return struct.unpack(">Q", padded)[0]


def ascon128_encrypt(
    key: bytes, nonce: bytes, associated_data: bytes, plaintext: bytes
) -> Tuple[bytes, bytes]:
    """
    NIST SP 800-232 Ascon-128 AEAD Encryption.
    Returns (ciphertext, 16-byte authentication tag).
    """
    if len(key) != 16 or len(nonce) != 16:
        raise ValueError("Ascon-128 requires a 16-byte key and 16-byte nonce.")

    k0, k1 = struct.unpack(">QQ", key)
    n0, n1 = struct.unpack(">QQ", nonce)
    s = [ASCON_128_IV, k0, k1, n0, n1]

    ascon_permutation(s, 0)
    s[3] ^= k0
    s[4] ^= k1

    # Associated Data Absorption
    if len(associated_data) > 0:
        ad_mv = memoryview(associated_data)
        while len(ad_mv) >= 8:
            s[0] ^= struct.unpack(">Q", ad_mv[:8])[0]
            ascon_permutation(s, 6)
            ad_mv = ad_mv[8:]
        s[0] ^= _pad_bytes_to_u64(bytes(ad_mv))
        ascon_permutation(s, 6)

    # Domain Separation
    s[4] ^= 1

    # Plaintext Absorption & Squeeze
    ct_chunks = bytearray()
    pt_mv = memoryview(plaintext)
    while len(pt_mv) >= 8:
        block = struct.unpack(">Q", pt_mv[:8])[0]
        s[0] ^= block
        ct_chunks.extend(struct.pack(">Q", s[0]))
        ascon_permutation(s, 6)
        pt_mv = pt_mv[8:]

    rem = bytes(pt_mv)
    s[0] ^= _pad_bytes_to_u64(rem)
    if len(rem) > 0:
        ct_chunks.extend(struct.pack(">Q", s[0])[: len(rem)])

    # Finalization
    s[1] ^= k0
    s[2] ^= k1
    ascon_permutation(s, 0)
    s[3] ^= k0
    s[4] ^= k1

    tag = struct.pack(">QQ", s[3] & MASK64, s[4] & MASK64)
    return bytes(ct_chunks), tag


def ascon128_decrypt(
    key: bytes,
    nonce: bytes,
    associated_data: bytes,
    ciphertext: bytes,
    tag: bytes,
) -> bytes:
    """
    NIST SP 800-232 Ascon-128 AEAD Decryption with constant-time tag verification.
    Raises ValueError on authentication failure and scrubs intermediate state.
    """
    if len(key) != 16 or len(nonce) != 16 or len(tag) != 16:
        raise ValueError("Ascon-128 requires 16-byte key, nonce, and tag.")

    k0, k1 = struct.unpack(">QQ", key)
    n0, n1 = struct.unpack(">QQ", nonce)
    s = [ASCON_128_IV, k0, k1, n0, n1]

    ascon_permutation(s, 0)
    s[3] ^= k0
    s[4] ^= k1

    if len(associated_data) > 0:
        ad_mv = memoryview(associated_data)
        while len(ad_mv) >= 8:
            s[0] ^= struct.unpack(">Q", ad_mv[:8])[0]
            ascon_permutation(s, 6)
            ad_mv = ad_mv[8:]
        s[0] ^= _pad_bytes_to_u64(bytes(ad_mv))
        ascon_permutation(s, 6)

    s[4] ^= 1

    pt_chunks = bytearray()
    ct_mv = memoryview(ciphertext)
    while len(ct_mv) >= 8:
        c0 = struct.unpack(">Q", ct_mv[:8])[0]
        pt_chunks.extend(struct.pack(">Q", s[0] ^ c0))
        s[0] = c0
        ascon_permutation(s, 6)
        ct_mv = ct_mv[8:]

    rem = bytes(ct_mv)
    rem_len = len(rem)
    if rem_len > 0:
        c_padded = rem + b"\x00" * (8 - rem_len)
        c_last = struct.unpack(">Q", c_padded)[0]
        mask = (MASK64 << (64 - 8 * rem_len)) & MASK64
        p_last = (s[0] ^ c_last) & mask
        pt_chunks.extend(struct.pack(">Q", p_last)[:rem_len])
        s[0] = (s[0] & (~mask & MASK64)) | c_last
    s[0] ^= 0x80 << (56 - 8 * rem_len)

    s[1] ^= k0
    s[2] ^= k1
    ascon_permutation(s, 0)
    s[3] ^= k0
    s[4] ^= k1

    computed_tag = struct.pack(">QQ", s[3] & MASK64, s[4] & MASK64)
    if not hmac.compare_digest(computed_tag, tag):
        for i in range(len(pt_chunks)):
            pt_chunks[i] = 0
        raise ValueError("Ascon-128 AEAD authentication tag mismatch (Tamper/Forgery detected).")

    return bytes(pt_chunks)


def ascon_hash256(message: bytes) -> bytes:
    """
    NIST SP 800-232 Ascon-Hash256 (256-bit sponge hash function).
    """
    s = [ASCON_HASH_IV, 0, 0, 0, 0]
    ascon_permutation(s, 0)

    mv = memoryview(message)
    while len(mv) >= 8:
        s[0] ^= struct.unpack(">Q", mv[:8])[0]
        ascon_permutation(s, 0)
        mv = mv[8:]

    s[0] ^= _pad_bytes_to_u64(bytes(mv))
    ascon_permutation(s, 0)

    out = bytearray()
    for i in range(4):
        out.extend(struct.pack(">Q", s[0] & MASK64))
        if i < 3:
            ascon_permutation(s, 0)
    return bytes(out)


def _present_sbox_layer(state: int, sbox: Tuple[int, ...]) -> int:
    out = 0
    for i in range(16):
        nib = (state >> (i * 4)) & 0xF
        out |= sbox[nib] << (i * 4)
    return out


def _present_p_layer(state: int) -> int:
    out = 0
    for i in range(64):
        pos = 63 if i == 63 else (16 * i) % 63
        out |= ((state >> i) & 1) << pos
    return out


def _present_inv_p_layer(state: int) -> int:
    out = 0
    for i in range(64):
        src = 63 if i == 63 else (16 * i) % 63
        out |= ((state >> src) & 1) << i
    return out


def _present80_round_keys(key: bytes) -> List[int]:
    if len(key) != 10:
        raise ValueError("PRESENT-80 requires an 80-bit (10-byte) key.")
    k_reg = int.from_bytes(key, "big")
    mask80 = (1 << 80) - 1
    rkeys: List[int] = []
    for r in range(1, 33):
        rkeys.append((k_reg >> 16) & MASK64)
        k_reg = (((k_reg << 61) & mask80) | (k_reg >> 19)) & mask80
        top_nib = (k_reg >> 76) & 0xF
        k_reg = (k_reg & ((1 << 76) - 1)) | (PRESENT_SBOX[top_nib] << 76)
        k_reg ^= (r & 0x1F) << 15
    return rkeys


def present80_encrypt_block(block: bytes, key: bytes) -> bytes:
    """ISO/IEC 29192-2 PRESENT-80 64-bit block encryption."""
    if len(block) != 8:
        raise ValueError("PRESENT-80 operates on 8-byte blocks.")
    rkeys = _present80_round_keys(key)
    state = int.from_bytes(block, "big")
    for r in range(31):
        state ^= rkeys[r]
        state = _present_sbox_layer(state, PRESENT_SBOX)
        state = _present_p_layer(state)
    state ^= rkeys[31]
    return (state & MASK64).to_bytes(8, "big")


def present80_decrypt_block(block: bytes, key: bytes) -> bytes:
    """ISO/IEC 29192-2 PRESENT-80 64-bit block decryption."""
    if len(block) != 8:
        raise ValueError("PRESENT-80 operates on 8-byte blocks.")
    rkeys = _present80_round_keys(key)
    state = int.from_bytes(block, "big")
    state ^= rkeys[31]
    for r in range(30, -1, -1):
        state = _present_inv_p_layer(state)
        state = _present_sbox_layer(state, PRESENT_INV_SBOX)
        state ^= rkeys[r]
    return (state & MASK64).to_bytes(8, "big")

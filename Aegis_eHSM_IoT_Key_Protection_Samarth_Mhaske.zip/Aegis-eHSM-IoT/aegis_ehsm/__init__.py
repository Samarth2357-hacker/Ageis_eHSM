"""
Aegis-eHSM: Lightweight Cryptography for IoT and Embedded Systems
Emulated Hardware Security Module for Embedded Key Protection

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
SPDX-License-Identifier: MIT
"""

from .crypto_primitives import (
    ascon_permutation,
    ascon_permutation_masked,
    ascon128_encrypt,
    ascon128_decrypt,
    ascon_hash256,
    present80_encrypt_block,
    present80_decrypt_block,
)
from .puf_engine import (
    BCH15_7_Codec,
    SRAMPhysicalUnclonableFunction,
    FuzzyExtractorRoT,
)
from .ehsm_module import (
    EmulatedHSM,
    KeySlotPermissions,
    HSMSecurityError,
    HSMTamperError,
    HSMReplayError,
    HSMAuthError,
)
from .side_channel_eval import (
    run_welch_t_test_tvla,
    run_comparative_benchmarks,
)

__author__ = "Samarth Mhaske"
__copyright__ = "Copyright (c) 2026 Samarth Mhaske. All Rights Reserved."
__version__ = "2.4.0"

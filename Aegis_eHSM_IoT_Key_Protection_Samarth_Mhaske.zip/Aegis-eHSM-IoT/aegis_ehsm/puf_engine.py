"""
Aegis-eHSM Silicon Root-of-Trust Engine:
SRAM Physical Unclonable Function (PUF) + BCH(15,7,5) Code-Offset Fuzzy Extractor

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
from .crypto_primitives import ascon_hash256

BCH15_7_POLY = 0x1D1  # g(x) = x^8 + x^7 + x^6 + x^4 + 1


class BCH15_7_Codec:
    """
    Systematic binary BCH(15, 7, d=5) error-correcting code.
    Corrects up to t = 2 bit flips per 15-bit codeword (13.3% error rate per word).
    """

    _CODEBOOK: Tuple[int, ...] = tuple()

    @classmethod
    def _init_codebook(cls) -> None:
        if not cls._CODEBOOK:
            cls._CODEBOOK = tuple(cls.encode(m) for m in range(128))

    @staticmethod
    def encode(data7: int) -> int:
        msg = data7 & 0x7F
        rem = msg << 8
        for i in range(14, 7, -1):
            if (rem >> i) & 1:
                rem ^= BCH15_7_POLY << (i - 8)
        return ((msg << 8) | (rem & 0xFF)) & 0x7FFF

    @classmethod
    def decode(cls, noisy_codeword: int) -> Tuple[int, int]:
        """Returns (decoded_7bit_msg, corrected_bit_errors)."""
        cls._init_codebook()
        masked = noisy_codeword & 0x7FFF
        best_msg = 0
        min_dist = 16
        for msg, cw in enumerate(cls._CODEBOOK):
            dist = (cw ^ masked).bit_count()
            if dist < min_dist:
                min_dist = dist
                best_msg = msg
                if dist == 0:
                    break
        return best_msg, min_dist


class SRAMPhysicalUnclonableFunction:
    """
    Emulates sub-micron CMOS transistor threshold voltage mismatch (V_th)
    across 256 x 15-bit bi-stable SRAM cells (3,840 bits total).
    """

    NUM_CELLS = 256

    def __init__(self, wafer_die_id: int = 0xC0FFEE42) -> None:
        self.wafer_die_id = wafer_die_id & 0xFFFFFFFF

    @staticmethod
    def _xorshift32(state: int) -> int:
        x = state & 0xFFFFFFFF
        if x == 0:
            x = 0x9E3779B9
        x = (x ^ ((x << 13) & 0xFFFFFFFF)) & 0xFFFFFFFF
        x = (x ^ (x >> 17)) & 0xFFFFFFFF
        x = (x ^ ((x << 5) & 0xFFFFFFFF)) & 0xFFFFFFFF
        return x

    def power_up_read(
        self, temperature_c: float = 25.0, supply_voltage_v: float = 3.3, trial_seed: int = 1
    ) -> Tuple[List[int], dict]:
        """
        Simulates an SRAM power-up readout under environmental stress.
        Nominal conditions: 25C, 3.3V -> 0% drift.
        Extreme conditions (-40C to +85C, voltage droop) introduce bounded metastable bit flips.
        """
        die_rng = self.wafer_die_id ^ 0xA5A55A5A
        temp_delta = abs(temperature_c - 25.0)
        volt_delta = abs(supply_voltage_v - 3.3)
        # Empirical SRAM bit error rate (BER) in parts-per-million
        ber_ppm = int(min(85000, temp_delta * 650 + volt_delta * 28000))

        noise_rng = (
            (self.wafer_die_id + int(temperature_c * 100) + int(supply_voltage_v * 1000) + trial_seed * 7919)
            ^ 0x3C6EF372
        ) & 0xFFFFFFFF

        cells: List[int] = []
        raw_flips = 0
        total_bits = self.NUM_CELLS * 15

        for _ in range(self.NUM_CELLS):
            die_rng = self._xorshift32(die_rng)
            base_word = die_rng & 0x7FFF
            flip_mask = 0
            if ber_ppm > 0:
                word_flips = 0
                for b in range(15):
                    noise_rng = self._xorshift32(noise_rng)
                    if (noise_rng % 1_000_000) < ber_ppm and word_flips < 2:
                        flip_mask |= 1 << b
                        word_flips += 1
                        raw_flips += 1
            cells.append((base_word ^ flip_mask) & 0x7FFF)

        metrics = {
            "wafer_die_id": f"0x{self.wafer_die_id:08X}",
            "temperature_c": round(temperature_c, 1),
            "supply_voltage_v": round(supply_voltage_v, 2),
            "total_sram_bits": total_bits,
            "raw_bit_flips": raw_flips,
            "raw_ber_percent": round((raw_flips / total_bits) * 100.0, 3),
        }
        return cells, metrics


@dataclass
class PUFHelperData:
    """Public Helper Data W stored in Non-Volatile Flash (leaks zero key bits)."""
    helper_codewords: List[int]
    enrollment_digest: bytes
    wafer_tag: str


class FuzzyExtractorRoT:
    """
    Code-Offset Fuzzy Extractor (Gen / Rep) combining BCH(15,7,5) error correction
    with NIST Ascon-Hash256 universal entropy extraction.
    """

    @staticmethod
    def enroll(sram_cells: List[int], wafer_tag: str = "STM32L4-DIE-01") -> Tuple[bytes, PUFHelperData]:
        if len(sram_cells) != SRAMPhysicalUnclonableFunction.NUM_CELLS:
            raise ValueError("Invalid SRAM cell array length.")

        secret_bytes = bytearray()
        helper_words: List[int] = []

        for idx, cell in enumerate(sram_cells):
            cs = (((cell >> 4) ^ (cell & 0x7F) ^ (idx * 17)) & 0x7F)
            secret_bytes.append(cs)
            cw = BCH15_7_Codec.encode(cs)
            helper_words.append((cw ^ cell) & 0x7FFF)

        root_key = ascon_hash256(bytes(secret_bytes))
        digest = ascon_hash256(root_key)
        return root_key, PUFHelperData(
            helper_codewords=helper_words,
            enrollment_digest=digest,
            wafer_tag=wafer_tag,
        )

    @staticmethod
    def reconstruct(noisy_cells: List[int], helper: PUFHelperData) -> Tuple[bytes, dict]:
        if len(noisy_cells) != len(helper.helper_codewords):
            raise ValueError("SRAM cell count mismatch with Helper Data.")

        recovered = bytearray()
        corrected_bits = 0
        cells_with_errors = 0

        for w, r_prime in zip(helper.helper_codewords, noisy_cells):
            noisy_cw = (w ^ r_prime) & 0x7FFF
            msg7, errs = BCH15_7_Codec.decode(noisy_cw)
            recovered.append(msg7)
            corrected_bits += errs
            if errs > 0:
                cells_with_errors += 1

        root_key = ascon_hash256(bytes(recovered))
        verify_digest = ascon_hash256(root_key)
        matched = verify_digest == helper.enrollment_digest

        stats = {
            "corrected_bits": corrected_bits,
            "cells_repaired": cells_with_errors,
            "post_fec_ber_percent": 0.0 if matched else 100.0,
            "root_key_verified": matched,
            "root_key_fingerprint": verify_digest[:8].hex(),
        }
        if not matched:
            raise RuntimeError("PUF Root-of-Trust reconstruction failed: silicon mismatch or extreme tamper.")
        return root_key, stats

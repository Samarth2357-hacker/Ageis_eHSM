"""
Aegis-eHSM Core Security Boundary:
Handle-Based Isolated Key Table, SP800-108 / Ascon-PRF Key Derivation,
Monotonic Anti-Rollback Nonce Generator, and Dual-Modular Redundancy (DMR)
Fault Injection Countermeasures.

Copyright (c) 2026 Samarth Mhaske. All Rights Reserved.
"""

from __future__ import annotations
import os
import struct
import time
from dataclasses import dataclass, field
from enum import IntFlag
from typing import Dict, List, Optional, Tuple

from .crypto_primitives import (
    ascon128_encrypt,
    ascon128_decrypt,
    ascon_hash256,
    present80_encrypt_block,
)
from .puf_engine import (
    SRAMPhysicalUnclonableFunction,
    FuzzyExtractorRoT,
    PUFHelperData,
)


class HSMSecurityError(Exception):
    """Base exception for eHSM security boundary violations."""


class HSMTamperError(HSMSecurityError):
    """Raised when a physical fault/glitch or DMR parity violation triggers zeroization."""


class HSMReplayError(HSMSecurityError):
    """Raised when an anti-rollback monotonic counter detects a replay attempt."""


class HSMAuthError(HSMSecurityError):
    """Raised when an AEAD tag fails constant-time verification."""


class KeySlotPermissions(IntFlag):
    ENCRYPT = 1 << 0
    DECRYPT = 1 << 1
    MAC_GEN = 1 << 2
    WRAP_UNWRAP = 1 << 3
    TELEMETRY_ALL = ENCRYPT | DECRYPT | MAC_GEN


@dataclass
class IsolatedKeySlot:
    slot_id: int
    label: str
    key_share_a: bytearray
    key_share_b: bytearray
    dmr_inverse: bytearray
    permissions: KeySlotPermissions
    monotonic_counter: int = 0
    last_rx_counter: int = -1
    locked: bool = False
    ops_count: int = 0

    def reconstruct_transient(self) -> bytes:
        """
        Recombines the 2-share Boolean masked key in transient memory
        and verifies the Dual-Modular Redundancy (DMR) inverse share.
        """
        raw = bytes(a ^ b for a, b in zip(self.key_share_a, self.key_share_b))
        for b_val, inv_val in zip(raw, self.dmr_inverse):
            if (b_val ^ inv_val) != 0xFF:
                raise HSMTamperError(
                    f"DMR parity fault detected in Key Slot #{self.slot_id} ({self.label})! "
                    "Single-Event Upset or laser/voltage glitch detected."
                )
        return raw

    def scrub(self) -> None:
        for i in range(len(self.key_share_a)):
            self.key_share_a[i] = 0
            self.key_share_b[i] = 0
            self.dmr_inverse[i] = 0
        self.ops_count = 0


class EmulatedHSM:
    """
    Software-Emulated Hardware Security Module (eHSM) for IoT & Embedded Systems.
    Never exposes raw cryptographic keys outside the security boundary; all caller
    operations reference integer `slot_id` handles.
    """

    MAX_SLOTS = 8

    def __init__(self, wafer_die_id: int = 0xC0FFEE42) -> None:
        self.puf = SRAMPhysicalUnclonableFunction(wafer_die_id=wafer_die_id)
        self.helper_data: Optional[PUFHelperData] = None
        self._root_share_a = bytearray(32)
        self._root_share_b = bytearray(32)
        self.slots: Dict[int, IsolatedKeySlot] = {}
        self.boot_epoch: int = 0
        self.tamper_latched: bool = False
        self.initialized: bool = False
        self.audit_log: List[dict] = []
        self.last_puf_stats: dict = {}

    def _log_event(self, event_type: str, detail: str, status: str = "OK") -> None:
        self.audit_log.append(
            {
                "timestamp": time.strftime("%H:%M:%S"),
                "epoch": self.boot_epoch,
                "event": event_type,
                "detail": detail,
                "status": status,
            }
        )
        if len(self.audit_log) > 100:
            self.audit_log.pop(0)

    def factory_enroll_puf(self) -> dict:
        """Performs one-time factory enrollment of the silicon SRAM PUF."""
        sram_cells, puf_meta = self.puf.power_up_read(temperature_c=25.0, supply_voltage_v=3.3)
        root_key, helper = FuzzyExtractorRoT.enroll(sram_cells, wafer_tag=puf_meta["wafer_die_id"])
        self.helper_data = helper

        # Store Root Key split across 2 Boolean shares in volatile SRAM
        mask = os.urandom(32)
        self._root_share_a = bytearray(r ^ m for r, m in zip(root_key, mask))
        self._root_share_b = bytearray(mask)
        self.boot_epoch = 1
        self.initialized = True
        self.tamper_latched = False
        self.last_puf_stats = {
            **puf_meta,
            "corrected_bits": 0,
            "cells_repaired": 0,
            "post_fec_ber_percent": 0.0,
            "root_key_verified": True,
            "root_key_fingerprint": helper.enrollment_digest[:8].hex(),
        }
        self._log_event(
            "PUF_ENROLL",
            f"Enrolled SRAM PUF ({puf_meta['wafer_die_id']}); Helper Data written to Flash (Zero NVM Key).",
        )
        return self.last_puf_stats

    def secure_boot_reconstruct(
        self, temperature_c: float = 65.0, supply_voltage_v: float = 3.15
    ) -> dict:
        """
        Simulates a field power-up under thermal/voltage stress, reconstructing the
        256-bit Root-of-Trust key strictly from noisy SRAM + public Helper Data.
        """
        if self.helper_data is None:
            self.factory_enroll_puf()
        assert self.helper_data is not None

        noisy_cells, puf_meta = self.puf.power_up_read(
            temperature_c=temperature_c, supply_voltage_v=supply_voltage_v, trial_seed=self.boot_epoch + 1
        )
        root_key, fec_stats = FuzzyExtractorRoT.reconstruct(noisy_cells, self.helper_data)

        mask = os.urandom(32)
        self._root_share_a = bytearray(r ^ m for r, m in zip(root_key, mask))
        self._root_share_b = bytearray(mask)
        self.boot_epoch += 1
        self.initialized = True
        self.tamper_latched = False

        self.last_puf_stats = {**puf_meta, **fec_stats}
        self._log_event(
            "SECURE_BOOT",
            f"Boot #{self.boot_epoch} at {temperature_c:.1f}C/{supply_voltage_v:.2f}V: "
            f"repaired {fec_stats['corrected_bits']} bit flips (0.00% post-FEC BER).",
        )
        return self.last_puf_stats

    def _get_root_key_transient(self) -> bytes:
        if not self.initialized or self.tamper_latched:
            raise HSMSecurityError("eHSM is uninitialized or locked in tamper-zeroized state.")
        return bytes(a ^ b for a, b in zip(self._root_share_a, self._root_share_b))

    def derive_key_slot(
        self,
        slot_id: int,
        context_label: str,
        permissions: KeySlotPermissions = KeySlotPermissions.TELEMETRY_ALL,
    ) -> dict:
        """
        Derives a 128-bit operational key into `slot_id` using Ascon-PRF KDF
        bound to the PUF Root-of-Trust, slot index, and domain context label.
        """
        if not (0 <= slot_id < self.MAX_SLOTS):
            raise ValueError(f"Slot ID must be in 0..{self.MAX_SLOTS - 1}")
        if slot_id in self.slots and self.slots[slot_id].locked:
            raise HSMSecurityError(f"Key Slot #{slot_id} is immutable/locked.")

        root = self._get_root_key_transient()
        kdf_blob = (
            root
            + b"|AEGIS-KDF-v2|"
            + context_label.encode("utf-8")
            + struct.pack(">BI", slot_id, int(permissions))
        )
        derived_full = ascon_hash256(kdf_blob)
        op_key = derived_full[:16]
        key_id_digest = ascon_hash256(op_key)[:6].hex()

        mask = os.urandom(16)
        share_a = bytearray(k ^ m for k, m in zip(op_key, mask))
        share_b = bytearray(mask)
        dmr_inv = bytearray((~k) & 0xFF for k in op_key)

        self.slots[slot_id] = IsolatedKeySlot(
            slot_id=slot_id,
            label=context_label,
            key_share_a=share_a,
            key_share_b=share_b,
            dmr_inverse=dmr_inv,
            permissions=permissions,
        )
        self._log_event(
            "KEY_DERIVE",
            f"Slot #{slot_id} ({context_label}) derived via Ascon-KDF [KeyID: {key_id_digest}].",
        )
        return {
            "slot_id": slot_id,
            "label": context_label,
            "key_fingerprint": key_id_digest,
            "permissions": int(permissions),
            "storage": "2-Share Masked SRAM + DMR Inverse",
        }

    def wrap_key_for_ota(self, kek_slot: int, target_slot: int) -> dict:
        """Wraps (encrypts + authenticates) a target key slot under a Key Encryption Key (KEK) slot."""
        if kek_slot not in self.slots or target_slot not in self.slots:
            raise HSMSecurityError("Invalid KEK or target key slot.")
        kek_obj = self.slots[kek_slot]
        tgt_obj = self.slots[target_slot]
        if not (kek_obj.permissions & KeySlotPermissions.WRAP_UNWRAP):
            raise HSMSecurityError(f"Slot #{kek_slot} lacks WRAP_UNWRAP permission.")

        kek_raw = kek_obj.reconstruct_transient()
        tgt_raw = tgt_obj.reconstruct_transient()
        kek_obj.monotonic_counter += 1
        nonce = struct.pack(">QQ", self.boot_epoch, kek_obj.monotonic_counter)
        ad = struct.pack(">BB", kek_slot, target_slot) + tgt_obj.label.encode("utf-8")
        wrapped_ct, tag = ascon128_encrypt(kek_raw, nonce, ad, tgt_raw)
        kek_obj.ops_count += 1

        self._log_event(
            "KEY_WRAP",
            f"Wrapped Slot #{target_slot} under KEK Slot #{kek_slot} (Blob: {len(wrapped_ct)}B).",
        )
        return {
            "kek_slot": kek_slot,
            "target_slot": target_slot,
            "wrapped_key_hex": wrapped_ct.hex(),
            "nonce_hex": nonce.hex(),
            "tag_hex": tag.hex(),
        }

    def seal_iot_telemetry(
        self, slot_id: int, associated_header: str, plaintext_payload: str
    ) -> dict:
        """
        Encrypts and authenticates IoT sensor telemetry inside the eHSM boundary
        using Dual-Modular Redundancy (DMR) to defeat fault injection attacks.
        """
        if slot_id not in self.slots:
            raise HSMSecurityError(f"Key Slot #{slot_id} is not provisioned.")
        slot = self.slots[slot_id]
        if not (slot.permissions & KeySlotPermissions.ENCRYPT):
            raise HSMSecurityError(f"Key Slot #{slot_id} lacks ENCRYPT permission.")

        try:
            key_primary = slot.reconstruct_transient()
        except HSMTamperError:
            self.zeroize_on_tamper("DMR Key Slot Parity Mismatch")
            raise

        slot.monotonic_counter += 1
        nonce = struct.pack(">QQ", self.boot_epoch, slot.monotonic_counter)
        ad_bytes = associated_header.encode("utf-8")
        pt_bytes = plaintext_payload.encode("utf-8")

        # Execution Path 1: Primary Reconstructed Share
        ct1, tag1 = ascon128_encrypt(key_primary, nonce, ad_bytes, pt_bytes)

        # Execution Path 2: Complementary DMR Inverse Verification
        key_shadow = bytes((~b) & 0xFF for b in slot.dmr_inverse)
        ct2, tag2 = ascon128_encrypt(key_shadow, nonce, ad_bytes, pt_bytes)

        if ct1 != ct2 or tag1 != tag2:
            self.zeroize_on_tamper("DMR Redundant Execution Mismatch (Glitch Detected)")
            raise HSMTamperError("Cryptographic pipeline fault detected during AEAD sealing!")

        # Also compute ultra-lightweight 64-bit PRESENT-80 tag preview for legacy RFID bridging
        rfid_mac = present80_encrypt_block(tag1[:8], key_primary[:10])
        slot.ops_count += 1

        self._log_event(
            "AEAD_SEAL",
            f"Slot #{slot_id} sealed {len(pt_bytes)}B payload [Counter={slot.monotonic_counter}].",
        )
        return {
            "slot_id": slot_id,
            "slot_label": slot.label,
            "epoch": self.boot_epoch,
            "counter": slot.monotonic_counter,
            "header": associated_header,
            "ciphertext_hex": ct1.hex(),
            "nonce_hex": nonce.hex(),
            "tag_hex": tag1.hex(),
            "present80_rfid_token": rfid_mac.hex(),
        }

    def unseal_iot_telemetry(
        self,
        slot_id: int,
        associated_header: str,
        ciphertext_hex: str,
        nonce_hex: str,
        tag_hex: str,
        enforce_anti_replay: bool = True,
    ) -> dict:
        """
        Verifies anti-rollback nonce freshness and authenticates + decrypts telemetry.
        """
        if slot_id not in self.slots:
            raise HSMSecurityError(f"Key Slot #{slot_id} is not provisioned.")
        slot = self.slots[slot_id]
        if not (slot.permissions & KeySlotPermissions.DECRYPT):
            raise HSMSecurityError(f"Key Slot #{slot_id} lacks DECRYPT permission.")

        try:
            key = slot.reconstruct_transient()
        except HSMTamperError:
            self.zeroize_on_tamper("DMR Key Slot Parity Mismatch on Unseal")
            raise

        nonce = bytes.fromhex(nonce_hex)
        ct = bytes.fromhex(ciphertext_hex)
        tag = bytes.fromhex(tag_hex)
        rx_epoch, rx_counter = struct.unpack(">QQ", nonce)

        if enforce_anti_replay and rx_counter <= slot.last_rx_counter:
            self._log_event(
                "REPLAY_BLOCKED",
                f"Rejected replayed packet on Slot #{slot_id} (Counter {rx_counter} <= {slot.last_rx_counter}).",
                status="ALERT",
            )
            raise HSMReplayError(
                f"Anti-Rollback Violation: packet counter {rx_counter} <= last accepted {slot.last_rx_counter}."
            )

        try:
            pt_bytes = ascon128_decrypt(key, nonce, associated_header.encode("utf-8"), ct, tag)
        except ValueError as exc:
            self._log_event(
                "AUTH_REJECTED",
                f"Slot #{slot_id} rejected forged/corrupted packet (128-bit Tag Mismatch).",
                status="ALERT",
            )
            raise HSMAuthError(str(exc)) from exc

        slot.last_rx_counter = rx_counter
        slot.ops_count += 1
        plaintext = pt_bytes.decode("utf-8", errors="replace")
        self._log_event(
            "AEAD_UNSEAL",
            f"Slot #{slot_id} verified & decrypted {len(pt_bytes)}B [Counter={rx_counter}].",
        )
        return {
            "slot_id": slot_id,
            "verified": True,
            "epoch": rx_epoch,
            "counter": rx_counter,
            "plaintext": plaintext,
        }

    def inject_fault_glitch(self, slot_id: int = 0, bit_flip_mask: int = 0x04) -> None:
        """
        Simulates a physical laser/voltage glitch flipping bits in SRAM Key Share A
        without updating the DMR inverse share, allowing live testing of tamper traps.
        """
        if slot_id not in self.slots:
            raise ValueError(f"Slot #{slot_id} not active.")
        self.slots[slot_id].key_share_a[0] ^= (bit_flip_mask & 0xFF)
        self._log_event(
            "FAULT_INJECT_SIM",
            f"Simulated physical voltage glitch on SRAM Slot #{slot_id} (Mask 0x{bit_flip_mask:02X}).",
            status="WARN",
        )

    def zeroize_on_tamper(self, reason: str = "Manual Tamper Trigger") -> None:
        """Immediately scrubs all root shares and operational key slots in SRAM."""
        for i in range(len(self._root_share_a)):
            self._root_share_a[i] = 0
            self._root_share_b[i] = 0
        for slot in self.slots.values():
            slot.scrub()
        self.slots.clear()
        self.tamper_latched = True
        self.initialized = False
        self._log_event(
            "TAMPER_ZEROIZE",
            f"EMERGENCY ZEROIZATION EXECUTED: {reason}. All SRAM keys scrubbed to 0x00.",
            status="CRITICAL",
        )

    def get_status_snapshot(self) -> dict:
        return {
            "initialized": self.initialized,
            "tamper_latched": self.tamper_latched,
            "boot_epoch": self.boot_epoch,
            "active_slots": [
                {
                    "slot_id": s.slot_id,
                    "label": s.label,
                    "counter": s.monotonic_counter,
                    "last_rx_counter": s.last_rx_counter,
                    "ops_count": s.ops_count,
                    "permissions": int(s.permissions),
                }
                for s in sorted(self.slots.values(), key=lambda x: x.slot_id)
            ],
            "puf_telemetry": self.last_puf_stats,
            "audit_log": list(reversed(self.audit_log[-15:])),
        }
